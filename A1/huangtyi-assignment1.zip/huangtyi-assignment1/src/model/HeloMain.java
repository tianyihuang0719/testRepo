/*
* TCSS 305 Autumn 2024
* Assignment 1
*/


package model;

/**
* Hello World
* This little program includes 2 classes, one has a instance method called
* from the other class. Displays a output "Hello World".
*
* @author Tianyi Huang
* @version 4 Oct 2024 // (use a date or any number you wish as the version)
*/

public class HeloMain {

    public static void main(final String[] theArgs) {
     // Create an instance of the Hello class
        final Helo heloObject = new Helo();
        
        // Call the sayHello() method from the Hello class
        heloObject.sayHelo();

    }

}
