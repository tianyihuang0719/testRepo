package model;

public class Helo {

    // Instance method to print a message
    public void sayHelo() {
        System.out.println("Hello World!");
    }

}
